import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TreeModule } from 'primeng/tree';
import { ContextMenuModule } from 'primeng/contextmenu';
import { InputTextModule } from 'primeng/inputtext';
import { TreeNode, TreeFilterService } from 'primeng/api';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'ebs-tree',
  imports: [
    CommonModule,
    TreeModule,
    ContextMenuModule,
    InputTextModule,
    FormsModule],
  templateUrl: './ebs-tree-component.html',
  styleUrl: './ebs-tree-component.css',
})
export class EbsTreeComponent {
  
  @Input() nodes: TreeNode[] = [];
  @Input() showFilter: boolean = true;
  @Input() showCheckbox: boolean = false;
  @Input() filterPlaceholder: string = 'بحث...';
  @Input() loading: boolean = false;

  @Output() nodeSelect = new EventEmitter<TreeNode>();
  @Output() nodeExpand = new EventEmitter<TreeNode>();
  @Output() nodeCollapse = new EventEmitter<TreeNode>();
  @Output() nodeClick = new EventEmitter<TreeNode>();
  @Output() filterChange = new EventEmitter<string>();

  selectedNodes: TreeNode | TreeNode[] | null = null;
  filterValue: string = '';
  contextMenuItems: any[] = [];

  constructor(private treeFilterService: TreeFilterService) {}

  ngOnInit(): void {
    this.initContextMenu();
  }

  onFilter(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.filterChange.emit(value);
  }

  onNodeSelect(event: any): void {
    this.nodeSelect.emit(event.node);
  }

  onNodeExpand(event: any): void {
    this.nodeExpand.emit(event.node);
  }

  onNodeCollapse(event: any): void {
    this.nodeCollapse.emit(event.node);
  }

  onNodeClick(event: any): void {
    this.nodeClick.emit(event.node);
  }

  onContextMenuSelect(event: any): void {
    // Context menu handled by PrimeNG
  }

  private initContextMenu(): void {
    this.contextMenuItems = [
      {
        label: 'توسيع الشجرة',
        icon: 'pi pi-plus',
        command: () => this.expandAll()
      },
      {
        label: 'طي الشجرة',
        icon: 'pi pi-minus',
        command: () => this.collapseAll()
      },
      {
        separator: true
      },
      {
        label: 'طباعة الشجرة',
        icon: 'pi pi-print',
        command: () => this.printTree()
      }
    ];
  }

  expandAll(): void {
    this.nodes.forEach(node => {
      this.expandRecursive(node, true);
    });
  }

  collapseAll(): void {
    this.nodes.forEach(node => {
      this.expandRecursive(node, false);
    });
  }

  private expandRecursive(node: TreeNode, isExpand: boolean): void {
    node.expanded = isExpand;
    if (node.children) {
      node.children.forEach(childNode => {
        this.expandRecursive(childNode, isExpand);
      });
    }
  }

  printTree(): void {
    window.print();
  }
}
